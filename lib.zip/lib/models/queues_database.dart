import 'queue_model.dart';

final Map<String, List<Queue>> userQueuesMap = {};