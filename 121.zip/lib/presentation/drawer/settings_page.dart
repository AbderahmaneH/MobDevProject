import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../database/models/user_model.dart';
import '../../core/app_colors.dart';
import '../../logic/app_cubit.dart';
import '../../logic/auth_cubit.dart';
import '../../core/localization.dart';
import '../../core/common_widgets.dart';
import 'privacy_policy_page.dart';
import 'terms_of_service_page.dart';
import '../welcome_page.dart';

class SettingsPage extends StatefulWidget {
  final User user;
  const SettingsPage({super.key, required this.user});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool queueNotifications = true;
  bool promotionalNotifications = false;
  bool soundAlerts = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: AppColors.backgroundLight,
        body: SafeArea(
          child: BlocListener<AuthCubit, AuthState>(
            listener: (context, state) {
              if (state is PasswordChanged) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(context.loc('password_changed')),
                    backgroundColor: AppColors.success,
                  ),
                );
              } else if (state is AuthFailure) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(state.error),
                    backgroundColor: AppColors.error,
                  ),
                );
              }
            },
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverAppBar(
                  title: Text(context.loc('settings')),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        // Language Settings
                        AppContainers.card(
                          context: context,
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: AppColors.primary
                                          .withAlpha((0.1 * 255).round()),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Icon(
                                      Icons.language,
                                      color: AppColors.primary,
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Text(
                                      context.loc('language'),
                                      style: AppTextStyles.getAdaptiveStyle(
                                        context,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              _buildLanguageSelector(context),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Notifications Settings
                        AppContainers.card(
                          context: context,
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: AppColors.primary
                                          .withAlpha((0.1 * 255).round()),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Icon(
                                      Icons.notifications_outlined,
                                      color: AppColors.primary,
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Text(
                                      context.loc('notifications'),
                                      style: AppTextStyles.getAdaptiveStyle(
                                        context,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              _buildSwitchSetting(
                                context: context,
                                title: context.loc('queue_notifications'),
                                subtitle:
                                    context.loc('queue_notifications_subtitle'),
                                value: queueNotifications,
                                onChanged: (value) {
                                  setState(() {
                                    queueNotifications = value;
                                  });
                                },
                              ),
                              const SizedBox(height: 12),
                              _buildSwitchSetting(
                                context: context,
                                title: context.loc('promotional_notifications'),
                                subtitle: context
                                    .loc('promotional_notifications_subtitle'),
                                value: promotionalNotifications,
                                onChanged: (value) {
                                  setState(() {
                                    promotionalNotifications = value;
                                  });
                                },
                              ),
                              const SizedBox(height: 12),
                              _buildSwitchSetting(
                                context: context,
                                title: context.loc('sound_alerts'),
                                subtitle: context.loc('sound_alerts_subtitle'),
                                value: soundAlerts,
                                onChanged: (value) {
                                  setState(() {
                                    soundAlerts = value;
                                  });
                                },
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        // Privacy Settings
                        AppContainers.card(
                          context: context,
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: AppColors.primary
                                          .withAlpha((0.1 * 255).round()),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Icon(
                                      Icons.security_outlined,
                                      color: AppColors.primary,
                                      size: 24,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Text(
                                      context.loc('privacy_security'),
                                      style: AppTextStyles.getAdaptiveStyle(
                                        context,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              _buildListTile(
                                context: context,
                                icon: Icons.privacy_tip_outlined,
                                title: context.loc('privacy_policy'),
                                onTap: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => const PrivacyPolicyPage(),
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(height: 12),
                              _buildListTile(
                                context: context,
                                icon: Icons.description_outlined,
                                title: context.loc('terms_of_service'),
                                onTap: () {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (_) => const TermsOfServicePage(),
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(height: 12),
                              _buildListTile(
                                context: context,
                                icon: Icons.lock_outline,
                                title: context.loc('change_pass'),
                                onTap: _showChangePasswordDialog,
                              ),
                              const SizedBox(height: 12),
                              _buildListTile(
                                context: context,
                                icon: Icons.delete_outline,
                                title: context.loc('delete_account'),
                                onTap: _showDeleteAccountDialog,
                                textColor: AppColors.error,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  void _showChangePasswordDialog() {
    final currentPasswordController = TextEditingController();
    final newPasswordController = TextEditingController();
    final confirmPasswordController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    bool _showPassword1 = false;
    bool _showPassword2 = false;
    bool _showPassword3 = false;

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: AppColors.adaptiveCardColor(context),
          title: Text(context.loc('change_pass')),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppTextFields.passwordField(
                  context: context,
                  hintText: context.loc('current_password'),
                  controller: currentPasswordController,
                  isVisible: _showPassword1,
                  onToggleVisibility: () =>
                      setState(() => _showPassword1 = !_showPassword1),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return context.loc('required_field');
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextFields.passwordField(
                  context: context,
                  hintText: context.loc('new_password'),
                  controller: newPasswordController,
                  isVisible: _showPassword2,
                  onToggleVisibility: () =>
                      setState(() => _showPassword2 = !_showPassword2),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return context.loc('required_field');
                    }
                    if (value.length < 6) {
                      return context.loc('password_too_short');
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextFields.passwordField(
                  context: context,
                  hintText: context.loc('confirm_new_password'),
                  controller: confirmPasswordController,
                  isVisible: _showPassword3,
                  onToggleVisibility: () =>
                      setState(() => _showPassword3 = !_showPassword3),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return context.loc('required_field');
                    }
                    if (value != newPasswordController.text) {
                      return context.loc('passwords_not_match');
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(context.loc('cancel')),
            ),
            ElevatedButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  context.read<AuthCubit>().changePassword(
                        userId: widget.user.id,
                        currentPassword: currentPasswordController.text,
                        newPassword: newPasswordController.text,
                      );
                  Navigator.pop(context);
                }
              },
              child: Text(context.loc('change')),
            ),
          ],
        );
      },
    );
  }

  void _showDeleteAccountDialog() {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text(context.loc('delete_account')),
          content: const Text(
            'This will permanently delete your account and data. Are you sure?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(context.loc('cancel')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              onPressed: () async {
                await context.read<AuthCubit>().deleteAccount(widget.user.id);
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const WelcomePage(),
                  ),
                );
                // Optional: show feedback
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Account deleted'),
                    backgroundColor: AppColors.error,
                  ),
                );
              },
              child: Text(context.loc('delete')),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSwitchSetting({
    required BuildContext context,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: AppTextStyles.getAdaptiveStyle(
                  context,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: AppTextStyles.getAdaptiveStyle(
                  context,
                  fontSize: 12,
                  lightColor: AppColors.textSecondaryLight,
                ),
              ),
            ],
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeThumbColor: AppColors.primary,
        ),
      ],
    );
  }

  Widget _buildListTile({
    required BuildContext context,
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? textColor,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppColors.primary.withAlpha((0.1 * 255).round()),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: textColor ?? AppColors.primary, size: 20),
      ),
      title: Text(
        title,
        style: AppTextStyles.getAdaptiveStyle(
          context,
          fontSize: 14,
          fontWeight: FontWeight.w500,
          lightColor: textColor ?? AppColors.textPrimaryLight,
        ),
      ),
      trailing: const Icon(
        Icons.arrow_forward_ios,
        size: 16,
        color: AppColors.textSecondaryLight,
      ),
      onTap: onTap,
    );
  }

  Widget _buildLanguageSelector(BuildContext context) {
    final languages = [
      {'code': 'en', 'name': 'English', 'flag': '🇺🇸'},
      {'code': 'fr', 'name': 'Français', 'flag': '🇫🇷'},
      {'code': 'ar', 'name': 'العربية', 'flag': '🇸🇦'},
    ];

    return BlocBuilder<AppCubit, AppState>(
      builder: (context, state) {
        final currentLanguage = QNowLocalizations().currentLocale.languageCode;

        return Column(
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: languages.map((lang) {
                final isSelected = currentLanguage == lang['code'];
                return GestureDetector(
                  onTap: () {
                    context
                        .read<AppCubit>()
                        .changeLanguage(Locale(lang['code']!));
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 12,
                    ),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primary
                          : AppColors.buttonSecondaryLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color:
                            isSelected ? AppColors.primary : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          lang['flag']!,
                          style: const TextStyle(fontSize: 28),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          lang['name']!,
                          style: TextStyle(
                            color: isSelected
                                ? AppColors.white
                                : AppColors.textPrimaryLight,
                            fontWeight:
                                isSelected ? FontWeight.w600 : FontWeight.w500,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        );
      },
    );
  }
}
